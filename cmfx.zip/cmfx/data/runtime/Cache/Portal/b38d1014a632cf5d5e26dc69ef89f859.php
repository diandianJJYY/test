<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta property="qc:admins" content="01676642316411516375"/>
    <meta name="keywords" content="fly,layui,前端社区">
    <meta name="description" content="Fly社区是跨设备模块化前端框架layui的官网社区，致力于为web开发提供强劲动力">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Fly - layui前端框架官方社区</title>
    	<?php  function _sp_helloworld(){ echo "hello ThinkCMF!"; } function _sp_helloworld2(){ echo "hello ThinkCMF2!"; } function _sp_helloworld3(){ echo "hello ThinkCMF3!"; } ?>
	<?php $portal_index_lastnews="1,2"; $portal_hot_articles="1,2"; $portal_last_post="1,2"; $tmpl=sp_get_theme_path(); $default_home_slides=array( array( "slide_name"=>"ThinkCMFX2.2.0发布啦！", "slide_pic"=>$tmpl."Public/assets/images/demo/1.jpg", "slide_url"=>"", ), array( "slide_name"=>"ThinkCMFX2.2.0发布啦！", "slide_pic"=>$tmpl."Public/assets/images/demo/2.jpg", "slide_url"=>"", ), array( "slide_name"=>"ThinkCMFX2.2.0发布啦！", "slide_pic"=>$tmpl."Public/assets/images/demo/3.jpg", "slide_url"=>"", ), ); ?>
	<meta name="author" content="ThinkCMF">
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">

   	<!-- No Baidu Siteapp-->
    <meta http-equiv="Cache-Control" content="no-siteapp"/>

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->
	<link rel="icon" href="/cmfx/themes/simplebootx/Public/assets/images/favicon.ico" type="image/x-icon">
	<link rel="shortcut icon" href="/cmfx/themes/simplebootx/Public/assets/images/favicon.ico" type="image/x-icon">
    <link href="/cmfx/themes/simplebootx/Public/assets/simpleboot/font-awesome/4.4.0/css/font-awesome.min.css"  rel="stylesheet" type="text/css">
	<!--[if IE 7]>
	<link rel="stylesheet" href="/cmfx/themes/simplebootx/Public/assets/simpleboot/font-awesome/4.4.0/css/font-awesome-ie7.min.css">
	<![endif]-->
    <link rel="stylesheet" href="//at.alicdn.com/t/font_001z27klwvobt9.css">
    <link rel="stylesheet" href="/cmfx/public/layui/layui.css">
    <link rel="stylesheet" href="/cmfx/public/layui/global.css">
    <link rel="stylesheet" href="/cmfx/public/layui/layer.css">
    <link rel="stylesheet" data-href="/cmfx/public/layui/css/layui.css">
    <script src="/cmfx/public/layui/layui.js"></script>
    <script src="/cmfx/public/js/jquery.js"></script>
	<style>
		/*html{filter:progid:DXImageTransform.Microsoft.BasicImage(grayscale=1);-webkit-filter: grayscale(1);}*/
		#backtotop{position: fixed;bottom: 50px;right:20px;display: none;cursor: pointer;font-size: 50px;z-index: 9999;}
		#backtotop:hover{color:#333}
		#main-menu-user li.user{display: none}
	</style>
	
</head>
<body>
<?php echo hook('body_start');?>
<div class="header">
<div class="main"><a class="logo" href="/cmfx/" title="Fly">Fly社区</a>
	<div class="nav">
		<?php
 $effected_id="main-menu"; $filetpl="<a href='\$href' target='\$target'>\$label</a>"; $foldertpl="<a href='\$href' target='\$target' class='dropdown-toggle' data-toggle='dropdown'>\$label <b class='caret'></b></a>"; $ul_class="dropdown-menu" ; $li_class="li-class"; $style="liu-nav"; $showlevel=6; $dropdown='dropdown'; echo sp_get_menu("main",$effected_id,$filetpl,$foldertpl,$ul_class,$li_class,$style,$showlevel,$dropdown); ?>
	</div>
	<div class="nav-user">
		<form action="<?php echo U('portal/search/index');?>" class="fly-search" method="post">
			<i class="iconfont icon-sousuo"></i>
			<input class="layui-input nav-search" autocomplete="off" placeholder="搜索内容，回车跳转" type="text" name="keyword" value="<?php echo I('get.keyword');?>">
		</form>
		<p class="out-login">
			<a class="iconfont icon-touxiang" href="/user/login/"></a>
		</p>
	</div>
</div>
</div>
<div class="main layui-clear">
    <div class="wrap">
        <div class="content">
            <!--<div class="fly-tab">-->
                <!--<span>-->
                    <!--<a href="/jie/">全部</a>-->
                    <!--<a href="/jie/unsolved/">未结帖</a>-->
                    <!--<a href="/jie/solved/">已采纳</a>-->
                    <!--<a href="/jie/wonderful/">精帖</a>-->
                <!--</span>-->
                <!--<form action="http://cn.bing.com/search" class="fly-search">-->
                    <!--<i class="iconfont icon-sousuo"></i> <input class="layui-input" autocomplete="off" placeholder="搜索内容，回车跳转" type="text" name="q">-->
                <!--</form>-->
                <!--<a href="/jie/add/" class="layui-btn jie-add">发布问题</a>-->
            <!--</div>-->
            <?php $lists = sp_sql_posts_paged("cid:$cat_id;order:post_date DESC;",10); ?>

            <ul class="fly-list">
                <?php if(is_array($lists['posts'])): $i = 0; $__LIST__ = $lists['posts'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i; $smeta=json_decode($vo['smeta'], true); ?>
                    <li class="fly-list-li">
                        <h2 class="fly-tip"><a  href="<?php echo leuu('article/index',array('id'=>$vo['object_id'],'cid'=>$vo['term_id']));?>" target="_blank"><?php echo ($vo["post_title"]); ?></a>
                            <!--<?php if($vo['istop']): ?>-->
                            <!--<span class="fly-tip-stick">置顶</span>-->
                            <!--<?php endif; ?>-->
                            <!--<?php if($vo['recommended']): ?>-->
                            <!--<span class="fly-tip-jing">精帖</span>-->
                            <!--<?php endif; ?>-->
                        </h2>
                        <p>
                            <span><a href="/u/168">管理员</a></span>
                            <span><?php echo ($vo["post_date"]); ?></span>
                            <?php $tags=explode(',',$vo['post_keywords']); ?>
                            <span>
                                <?php if(is_array($tags)): $i = 0; $__LIST__ = $tags;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$tag): $mod = ($i % 2 );++$i;?><a href="javascript:;" class="tags" name="<?php echo ($tag); ?>"><?php echo ($tag); ?> </a><?php endforeach; endif; else: echo "" ;endif; ?>
                            </span>
                            <span class="fly-list-hint">
                                <i class="iconfont" title="回答">&#xe60c;</i> <?php echo ($vo["comment_count"]); ?>
                                <i class="iconfont" title="人气">&#xe60b;</i> <?php echo ($vo["post_hits"]); ?>
                            </span>
                        </p>
                        <div class="liu-article-img">
                            <a href="<?php echo leuu('article/index',array('id'=>$vo['object_id'],'cid'=>$vo['term_id']));?>" class="fly-list-pic">
                                <?php if(empty($smeta['thumb'])): ?><img src="/cmfx/public/images/default_article.png" class="liu-img-responsive" alt="<?php echo ($vo["post_title"]); ?>"/>
                                    <?php else: ?>
                                    <img src="<?php echo sp_get_asset_upload_path($smeta['thumb']);?>" class="liu-img-responsive img-thumbnail" alt="<?php echo ($vo["post_title"]); ?>" /><?php endif; ?>
                            </a>
                        </div>
                        <div class="liu-article-beginning"><?php echo strip_tags(substr($vo['post_content'],0,1022));?></div>
                        <a href="<?php echo leuu('article/index',array('id'=>$vo['object_id'],'cid'=>$vo['term_id']));?>" class="liu-readall" target="_blank">阅读全文</a>
                    </li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
            <div class="layui-box layui-laypage layui-laypage-default liu-page"><ul><?php echo ($lists['page']); ?></ul></div>
        </div>
    </div>
    <div class="edge"><h3 class="page-title">标签云</h3>
        <div class="liu-tags">
            <?php $keywords = _sp_sql_keywords_bypostcatid(); $class_arr = array('','layui-btn-warm','layui-btn-danger','layui-btn-normal'); ?>
             <?php if(is_array($keywords[0])): $i = 0; $__LIST__ = $keywords[0];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><a href="javascript:;" class="tags layui-btn layui-btn-small <?php echo ($class_arr[(($i-1)%4)]); ?>" name="<?php echo ($key); ?>"><?php echo ($key); ?>（<?php echo ($vo); ?>）</a><?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
        <div style="">
            <script type="text/javascript">        /*336*280*/
            var cpro_id = "u2482656";
            </script>
            <script type="text/javascript" src="http://cpro.baidustatic.com/cpro/ui/c.js"></script>
        </div>
        <?php $hot_articles=sp_sql_posts("field:post_title,post_excerpt,post_hits,object_id,term_id,smeta;order:post_hits desc;limit:8;"); ?>
        <h3 class="page-title">热门文章</h3>
        <ol class="fly-list-one">
            <?php if(is_array($hot_articles)): foreach($hot_articles as $key=>$vo): ?><li>
                    <a href="<?php echo leuu('article/index',array('id'=>$vo['object_id'],'cid'=>$vo['term_id']));?>"><?php echo ($vo["post_title"]); ?></a>
                    <span><i class="iconfont">&#xe60b;</i> <?php echo ($vo["post_hits"]); ?></span>
                </li><?php endforeach; endif; ?>
        </ol>
        <h3 class="page-title">最新评论</h3>
        <div>
            <?php $last_comments=sp_get_comments("field:*;limit:0,5;order:createtime desc;"); ?>
            <?php if(is_array($last_comments)): foreach($last_comments as $key=>$vo): ?><ul class="liu-new-comment">
                    <img alt="" src="<?php echo U('user/public/avatar',array('id'=>$vo['uid']));?>" class="">
                    <li class="liu-user-name">
                        <?php echo ($vo["full_name"]); ?>
                    </li>
                    <li class="liu-post-title">
                        在<a href="/cmfx/<?php echo ($vo["url"]); ?>#comment<?php echo ($vo["id"]); ?>"><?php echo (msubstr($vo["post_title"],0,15)); ?></a>中评论：
                    </li>
                    <li class="liu-content">
                        <?php echo ($vo["content"]); ?>
                    </li>
                </ul><?php endforeach; endif; ?>
        </div>
        <div class="fly-link">
            <span>友情链接：</span>
            <div class="links">
                <?php $links=sp_getlinks(); ?>
                <?php if(is_array($links)): foreach($links as $key=>$vo): if(!empty($vo["link_image"])): ?><!-- <img src="<?php echo sp_get_image_url($vo['link_image']);?>"> --><!-- 如果想加个友链图片可以取消注释 --><?php endif; ?>
                    <a href="<?php echo ($vo["link_url"]); ?>" target="<?php echo ($vo["link_target"]); ?>"><?php echo ($vo["link_name"]); ?></a><?php endforeach; endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Footer ================================================== -->
<?php echo hook('footer');?>
<div class="footer">
	<p>
		<a href="http://fly.layui.com/">Fly社区</a> 2016 &copy;
		<a href="http://www.layui.com/">layui.com</a>
	</p>
	<p>
		<a href="http://fly.layui.com/jie/3147.html" target="_blank">产品授权</a>
		<a href="http://fly.layui.com/jie/4536.html" target="_blank">获取Fly社区模版</a>
		<a href="http://fly.layui.com/jie/2461.html" target="_blank">微信公众号</a>
	</p>
</div>
<div id="backtotop">
	<i class="fa fa-arrow-circle-up"></i>
</div>
<?php echo ($site_tongji); ?>

<script type="text/javascript">
//全局变量
var GV = {
    ROOT: "/cmfx/",
    WEB_ROOT: "/cmfx/",
    JS_ROOT: "public/js/"
};
layui.use('layer', function() {
   var layer = layui.layer;
});
</script>
   <!-- Placed at the end of the document so the pages load faster -->
   <script src="/cmfx/public/js/jquery.js"></script>
   <script src="/cmfx/public/js/wind.js"></script>
   <script src="/cmfx/themes/simplebootx/Public/assets/simpleboot/bootstrap/js/bootstrap.min.js"></script>
   <script src="/cmfx/public/js/frontend.js"></script>
<script>
$(function(){
	$('body').on('touchstart.dropdown', '.dropdown-menu', function (e) { e.stopPropagation(); });
	
	$("#main-menu li.dropdown").hover(function(){
		$(this).addClass("open");
	},function(){
		$(this).removeClass("open");
	});
	
	$.post("<?php echo U('user/index/is_login');?>",{},function(data){
		if(data.status==1){
			if(data.user.avatar){
				$("#main-menu-user .headicon").attr("src",data.user.avatar.indexOf("http")==0?data.user.avatar:"<?php echo sp_get_image_url('[AVATAR]','!avatar');?>".replace('[AVATAR]',data.user.avatar));
			}
			
			$("#main-menu-user .user-nicename").text(data.user.user_nicename!=""?data.user.user_nicename:data.user.user_login);
			$("#main-menu-user li.login").show();
			
		}
		if(data.status==0){
			$("#main-menu-user li.offline").show();
		}
		
		/* $.post("<?php echo U('user/notification/getLastNotifications');?>",{},function(data){
			$(".nav .notifactions .count").text(data.list.length);
		}); */
		
	});	
	;(function($){
		$.fn.totop=function(opt){
			var scrolling=false;
			return this.each(function(){
				var $this=$(this);
				$(window).scroll(function(){
					if(!scrolling){
						var sd=$(window).scrollTop();
						if(sd>100){
							$this.fadeIn();
						}else{
							$this.fadeOut();
						}
					}
				});
				
				$this.click(function(){
					scrolling=true;
					$('html, body').animate({
						scrollTop : 0
					}, 500,function(){
						scrolling=false;
						$this.fadeOut();
					});
				});
			});
		};
	})(jQuery); 
	
	$("#backtotop").totop();
	
	
});
</script>

<!-- 点击标签云搜索 -->
<script>
   $(".tags").click(function () {
      var $this = $(this);
      var $form = $("form");
      var keyword = $.trim($this.attr('name'));
      if(keyword == '') {
         layer.msg('关键词不能为空，请重新输入！');
         return;
      }
      $(".nav-search").val(keyword);
      $form.submit();
   });
</script>


<script src="/cmfx/public/layui/layui.js"></script>

<script>layui.cache.page = 'index';
layui.cache.user = {
    username: '游客',
    uid: -1,
    avatar: 'http://res.layui.com/images/fly/avatar/00.jpg',
    experience: 0,
    sum: 0,
    vip: 0,
    sex: ''
};
layui.config({version: "1481533561394"}).extend({'fly': 'http://res.layui.com/lay/modules/fly/index'}).use('fly');
</script>
<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cspan id='cnzz_stat_icon_30088308'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "w.cnzz.com/c.php%3Fid%3D30088308' type='text/javascript'%3E%3C/script%3E"));</script>
</body>
</html>