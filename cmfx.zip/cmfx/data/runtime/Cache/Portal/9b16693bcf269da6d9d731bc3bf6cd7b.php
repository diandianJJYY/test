<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<title><?php echo ($name); ?> <?php echo ($seo_title); ?> <?php echo ($site_name); ?></title>
<meta name="keywords" content="<?php echo ($seo_keywords); ?>" />
<meta name="description" content="<?php echo ($seo_description); ?>">
	<?php  function _sp_helloworld(){ echo "hello ThinkCMF!"; } function _sp_helloworld2(){ echo "hello ThinkCMF2!"; } function _sp_helloworld3(){ echo "hello ThinkCMF3!"; } ?>
	<?php $portal_index_lastnews="1,2"; $portal_hot_articles="1,2"; $portal_last_post="1,2"; $tmpl=sp_get_theme_path(); $default_home_slides=array( array( "slide_name"=>"ThinkCMFX2.2.0发布啦！", "slide_pic"=>$tmpl."Public/assets/images/demo/1.jpg", "slide_url"=>"", ), array( "slide_name"=>"ThinkCMFX2.2.0发布啦！", "slide_pic"=>$tmpl."Public/assets/images/demo/2.jpg", "slide_url"=>"", ), array( "slide_name"=>"ThinkCMFX2.2.0发布啦！", "slide_pic"=>$tmpl."Public/assets/images/demo/3.jpg", "slide_url"=>"", ), ); ?>
	<meta name="author" content="ThinkCMF">
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">

   	<!-- No Baidu Siteapp-->
    <meta http-equiv="Cache-Control" content="no-siteapp"/>

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->
	<link rel="icon" href="/cmfx/themes/simplebootx/Public/assets/images/favicon.ico" type="image/x-icon">
	<link rel="shortcut icon" href="/cmfx/themes/simplebootx/Public/assets/images/favicon.ico" type="image/x-icon">
    <link href="/cmfx/themes/simplebootx/Public/assets/simpleboot/font-awesome/4.4.0/css/font-awesome.min.css"  rel="stylesheet" type="text/css">
	<!--[if IE 7]>
	<link rel="stylesheet" href="/cmfx/themes/simplebootx/Public/assets/simpleboot/font-awesome/4.4.0/css/font-awesome-ie7.min.css">
	<![endif]-->
    <link rel="stylesheet" href="//at.alicdn.com/t/font_001z27klwvobt9.css">
    <link rel="stylesheet" href="/cmfx/public/layui/layui.css">
    <link rel="stylesheet" href="/cmfx/public/layui/global.css">
    <link rel="stylesheet" href="/cmfx/public/layui/layer.css">
    <link rel="stylesheet" data-href="/cmfx/public/layui/css/layui.css">
    <script src="/cmfx/public/layui/layui.js"></script>
    <script src="/cmfx/public/js/jquery.js"></script>
	<style>
		/*html{filter:progid:DXImageTransform.Microsoft.BasicImage(grayscale=1);-webkit-filter: grayscale(1);}*/
		#backtotop{position: fixed;bottom: 50px;right:20px;display: none;cursor: pointer;font-size: 50px;z-index: 9999;}
		#backtotop:hover{color:#333}
		#main-menu-user li.user{display: none}
	</style>
	
</head>
<body>
	<?php echo hook('body_start');?>
<div class="header">
<div class="main"><a class="logo" href="/cmfx/" title="Fly">Fly社区</a>
	<div class="nav">
		<?php
 $effected_id="main-menu"; $filetpl="<a href='\$href' target='\$target'>\$label</a>"; $foldertpl="<a href='\$href' target='\$target' class='dropdown-toggle' data-toggle='dropdown'>\$label <b class='caret'></b></a>"; $ul_class="dropdown-menu" ; $li_class="li-class"; $style="liu-nav"; $showlevel=6; $dropdown='dropdown'; echo sp_get_menu("main",$effected_id,$filetpl,$foldertpl,$ul_class,$li_class,$style,$showlevel,$dropdown); ?>
	</div>
	<div class="nav-user">
		<form action="<?php echo U('portal/search/index');?>" class="fly-search" method="post">
			<i class="iconfont icon-sousuo"></i>
			<input class="layui-input nav-search" autocomplete="off" placeholder="搜索内容，回车跳转" type="text" name="keyword" value="<?php echo I('get.keyword');?>">
		</form>
		<p class="out-login">
			<a class="iconfont icon-touxiang" href="/user/login/"></a>
		</p>
	</div>
</div>
</div>
	<div class="container">
		<?php $lists = sp_sql_posts_paged("cid:$cat_id;order:post_date DESC;",20); ?>
		<div id="container">
			<div class="grid-sizer"></div>
			<?php if(is_array($lists['posts'])): $i = 0; $__LIST__ = $lists['posts'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i; $smeta=json_decode($vo['smeta'], true); ?>

			<div class="item liu-item">
				<div class="tc-gridbox">
					<div class="list-masonry-header">
						<h3>
							<a href="<?php echo leuu('article/index',array('id'=>$vo['object_id'],'cid'=>$vo['term_id']));?>"><?php echo ($vo["post_title"]); ?></a>
						</h3>
						<?php if(!empty($smeta['thumb'])): ?><div class="item-image">
								<a href="<?php echo leuu('article/index',array('id'=>$vo['object_id'],'cid'=>$vo['term_id']));?>">
									<img src="<?php echo sp_get_asset_upload_path($smeta['thumb']);?>"
										 class="liu-img-responsive" alt="<?php echo ($vo["post_title"]); ?>">
								</a>
							</div><?php endif; ?>
					</div>
					<div class="list-masonry-body">
						<a href="<?php echo leuu('article/index',array('id'=>$vo['object_id'],'cid'=>$vo['term_id']));?>"><?php echo (msubstr($vo["post_excerpt"],0,256)); ?></a>
					</div>
					<div class="list-masonry-footer">
						<div class="pull-left">
							<span class="meta"><?php echo ($vo["post_date"]); ?></span>
						</div>
						<div class="pull-right">
							<a href="javascript:;"><i class="fa fa-eye"></i><span><?php echo ($vo["post_hits"]); ?></span></a>
							<a href="<?php echo U('article/do_like',array('id'=>$vo['object_id']));?>" class="js-count-btn"><i class="fa fa-thumbs-up"></i><span class="count"><?php echo ($vo["post_like"]); ?></span></a> 
							<a href="<?php echo U('user/favorite/do_favorite',array('id'=>$vo['object_id']));?>" class="js-favorite-btn" data-title="<?php echo ($vo["post_title"]); ?>" data-url="<?php echo leuu('portal/article/index',array('id'=>$vo['object_id'],'cid'=>$vo['term_id']));?>" data-key="<?php echo sp_get_favorite_key('posts',$vo['object_id']);?>">
								<i class="fa fa-star-o"></i>
							</a>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div><?php endforeach; endif; else: echo "" ;endif; ?>
		</div>
		<!-- <div class="pagination"><ul><?php echo ($lists['page']); ?></ul></div> -->
		<div class="js-infinite-scroll-loading text-center" style="display: none;">正在加载...</div>
		<div id="nextpage"></div>
	</div>
    
<!-- Footer ================================================== -->
<?php echo hook('footer');?>
<div class="footer">
	<p>
		<a href="http://fly.layui.com/">Fly社区</a> 2016 &copy;
		<a href="http://www.layui.com/">layui.com</a>
	</p>
	<p>
		<a href="http://fly.layui.com/jie/3147.html" target="_blank">产品授权</a>
		<a href="http://fly.layui.com/jie/4536.html" target="_blank">获取Fly社区模版</a>
		<a href="http://fly.layui.com/jie/2461.html" target="_blank">微信公众号</a>
	</p>
</div>
<div id="backtotop">
	<i class="fa fa-arrow-circle-up"></i>
</div>
<?php echo ($site_tongji); ?>


	<!-- JavaScript -->
	<script type="text/javascript">
//全局变量
var GV = {
    ROOT: "/cmfx/",
    WEB_ROOT: "/cmfx/",
    JS_ROOT: "public/js/"
};
layui.use('layer', function() {
   var layer = layui.layer;
});
</script>
   <!-- Placed at the end of the document so the pages load faster -->
   <script src="/cmfx/public/js/jquery.js"></script>
   <script src="/cmfx/public/js/wind.js"></script>
   <script src="/cmfx/themes/simplebootx/Public/assets/simpleboot/bootstrap/js/bootstrap.min.js"></script>
   <script src="/cmfx/public/js/frontend.js"></script>
<script>
$(function(){
	$('body').on('touchstart.dropdown', '.dropdown-menu', function (e) { e.stopPropagation(); });
	
	$("#main-menu li.dropdown").hover(function(){
		$(this).addClass("open");
	},function(){
		$(this).removeClass("open");
	});
	
	$.post("<?php echo U('user/index/is_login');?>",{},function(data){
		if(data.status==1){
			if(data.user.avatar){
				$("#main-menu-user .headicon").attr("src",data.user.avatar.indexOf("http")==0?data.user.avatar:"<?php echo sp_get_image_url('[AVATAR]','!avatar');?>".replace('[AVATAR]',data.user.avatar));
			}
			
			$("#main-menu-user .user-nicename").text(data.user.user_nicename!=""?data.user.user_nicename:data.user.user_login);
			$("#main-menu-user li.login").show();
			
		}
		if(data.status==0){
			$("#main-menu-user li.offline").show();
		}
		
		/* $.post("<?php echo U('user/notification/getLastNotifications');?>",{},function(data){
			$(".nav .notifactions .count").text(data.list.length);
		}); */
		
	});	
	;(function($){
		$.fn.totop=function(opt){
			var scrolling=false;
			return this.each(function(){
				var $this=$(this);
				$(window).scroll(function(){
					if(!scrolling){
						var sd=$(window).scrollTop();
						if(sd>100){
							$this.fadeIn();
						}else{
							$this.fadeOut();
						}
					}
				});
				
				$this.click(function(){
					scrolling=true;
					$('html, body').animate({
						scrollTop : 0
					}, 500,function(){
						scrolling=false;
						$this.fadeOut();
					});
				});
			});
		};
	})(jQuery); 
	
	$("#backtotop").totop();
	
	
});
</script>

<!-- 点击标签云搜索 -->
<script>
   $(".tags").click(function () {
      var $this = $(this);
      var $form = $("form");
      var keyword = $.trim($this.attr('name'));
      if(keyword == '') {
         layer.msg('关键词不能为空，请重新输入！');
         return;
      }
      $(".nav-search").val(keyword);
      $form.submit();
   });
</script>


	<script src="/cmfx/themes/simplebootx/Public/assets/js/imagesloaded.pkgd.min.js"></script>
	<script src="/cmfx/themes/simplebootx/Public/assets/js/masonry.pkgd.min.js"></script>
	<script src="/cmfx/themes/simplebootx/Public/assets/js/jquery.infiniteScroll.js"></script>
	<script>
		
		$(function(){
			var $container= $('#container').masonry({
				columnWidth : '.grid-sizer',
				itemSelector : '.item'
			});
			
			$container.imagesLoaded().progress(function (imgLoad, image) {
				var msnry = $container.data('masonry');
				var itemSelector = msnry.options.itemSelector;
		        var $item = $(image.img).parents(itemSelector);
		        $('.tc-gridbox',$item).css('opacity',1);
		        msnry.layout();
		    });
			
			$('#nextpage').infiniteScroll({
				loading:'.js-infinite-scroll-loading',
				total_pages:<?php echo ($lists['total_pages']); ?>,
				success:function(content){
					var $items=$(content).find('#container .item');
					if($items.length>0){
						//$('.tc-gridbox',$items).css('opacity',1);
						$container.append( $items )
					    // add and layout newly prepended items
					    .masonry( 'appended', $items );
						$items.imagesLoaded().progress(function (imgLoad, image) {
							var msnry = $container.data('masonry');
							var itemSelector = msnry.options.itemSelector;
					        var $item = $(image.img).parents(itemSelector);
					        $('.tc-gridbox',$item).css('opacity',1);
					        msnry.layout();
					    });
					}
				},
				finish:function(){
					
				}
			});
		});
		
		
		
		
	</script>
</body>
</html>