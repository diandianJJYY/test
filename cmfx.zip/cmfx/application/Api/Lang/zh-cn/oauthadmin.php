<?php
return array(
    "QQ_CONNECT" => 'QQ互联登录设置',
    "WEIBO_CONNECT" => '新浪微博登录设置',
    "CLICK_HERE" => '点击此处',
    "GET_QQ_APPKEY_AND_APPSECRET" => '获取QQ互联APPKey及APPsecret',
    "GET_WEIBO_APPKEY_AND_APPSECRET" => "获取新浪微博APPKey及APPsecret",
    "CALLBACK_URL"  => '授权回调页',
    "CANCEL_CALLBACK_URL" => '取消授权回调页',
    
);