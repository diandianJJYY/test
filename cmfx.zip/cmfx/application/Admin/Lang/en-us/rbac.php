<?php
return array(
		"ROLE_NAME" => 'Role Name',
		"ROLE_DESCRIPTION" => 'Role Description',
		"ROLE_SETTING" => 'Setting'
);